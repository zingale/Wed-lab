! ***********************************************************************
!
!   Copyright (C) 2012-2019  Bill Paxton & The MESA Team
!
!   This program is free software: you can redistribute it and/or modify
!   it under the terms of the GNU Lesser General Public License
!   as published by the Free Software Foundation,
!   either version 3 of the License, or (at your option) any later version.
!
!   This program is distributed in the hope that it will be useful,
!   but WITHOUT ANY WARRANTY; without even the implied warranty of
!   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
!   See the GNU Lesser General Public License for more details.
!
!   You should have received a copy of the GNU Lesser General Public License
!   along with this program. If not, see <https://www.gnu.org/licenses/>.
!
! ***********************************************************************

module run_binary_extras

   use star_lib
   use star_def
   use const_def
   use chem_def
   use num_lib
   use binary_def
   use math_lib

   implicit none

contains

   subroutine extras_binary_controls(binary_id, ierr)
      integer :: binary_id
      integer, intent(out) :: ierr
      type(binary_info), pointer :: b
      ierr = 0

      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
         write (*, *) 'failed in binary_ptr'
         return
      end if

      ! Set these function pointers to point to the functions you wish to use in
      ! your run_binary_extras. Any which are not set, default to a null_ version
      ! which does nothing.
      b%how_many_extra_binary_history_header_items => how_many_extra_binary_history_header_items
      b%data_for_extra_binary_history_header_items => data_for_extra_binary_history_header_items
      b%how_many_extra_binary_history_columns => how_many_extra_binary_history_columns
      b%data_for_extra_binary_history_columns => data_for_extra_binary_history_columns

      b%extras_binary_startup => extras_binary_startup
      b%extras_binary_start_step => extras_binary_start_step
      b%extras_binary_check_model => extras_binary_check_model
      b%extras_binary_finish_step => extras_binary_finish_step
      b%extras_binary_after_evolve => extras_binary_after_evolve

      ! Once you have set the function pointers you want, then uncomment this (or set it in your star_job inlist)
      ! to disable the printed warning message,
      b%warn_binary_extra = .false.

      ! EXTRA SHRINKAGE FOR L2 MASS OUTFLOW!
      ! Default routine: $MESA_DIR/binary/private/binary_jdot.f90
      ! But the empty hook from where you usually start is: 
      ! $MESA_DIR/binary/other/mod_other_binary_jdot.f90
      b% other_jdot_ml => my_jdot_ml

      ! Default routine: $MESA_DIR/binary/private/binary_mdot.f90
      ! But the empty hook from where you usually start is: 
      ! $MESA_DIR/binary/other/mod_other_adjust_mdots.f90
      b% other_adjust_mdots => my_adjust_mdots

   end subroutine extras_binary_controls

   integer function how_many_extra_binary_history_header_items(binary_id)
      use binary_def, only: binary_info
      integer, intent(in) :: binary_id
      how_many_extra_binary_history_header_items = 0
   end function how_many_extra_binary_history_header_items

   subroutine data_for_extra_binary_history_header_items( &
      binary_id, n, names, vals, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id, n
      character(len=maxlen_binary_history_column_name) :: names(n)
      real(dp) :: vals(n)
      integer, intent(out) :: ierr
      ierr = 0
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
         write (*, *) 'failed in binary_ptr'
         return
      end if
   end subroutine data_for_extra_binary_history_header_items

   integer function how_many_extra_binary_history_columns(binary_id)
      use binary_def, only: binary_info
      integer, intent(in) :: binary_id
      how_many_extra_binary_history_columns = 2
   end function how_many_extra_binary_history_columns

   subroutine data_for_extra_binary_history_columns(binary_id, n, names, vals, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(in) :: n
      character(len=maxlen_binary_history_column_name) :: names(n)
      real(dp) :: vals(n)
      integer, intent(out) :: ierr
      ierr = 0
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
         write (*, *) 'failed in binary_ptr'
         return
      end if

      names(1) = 'tdelay(Gyr)'
      vals(1) = (5d0/256d0) * (clight**5 * b%separation**4) / &
      (standard_cgrav**3 * b%m(1) * b%m(2) * (b%m(1) + b%m(2)))

      ! convert from seconds -> years -> Gyr
      vals(1) = vals(1) / secyer / 1d9

      ! L2 mass outflow rate in Msun/yr
      names(2) = "lg_mdot_L2"
      ! Let's take the log of the absolute value 
      vals(2) = log10(abs((b% mtransfer_rate * b% s_donor% x_ctrl(1) )/Msun*secyer))

   end subroutine data_for_extra_binary_history_columns

   integer function extras_binary_startup(binary_id, restart, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr
      logical, intent(in) :: restart
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if

!          b% s1% job% warn_run_star_extras = .false.
      extras_binary_startup = keep_going
   end function extras_binary_startup

   integer function extras_binary_start_step(binary_id, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr

      extras_binary_start_step = keep_going
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if

   end function extras_binary_start_step

   ! Return either keep_going, retry, or terminate
   integer function extras_binary_check_model(binary_id)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer :: ierr
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if
      extras_binary_check_model = keep_going

   end function extras_binary_check_model

   ! returns either keep_going or terminate.
   ! note: cannot request retry; extras_check_model can do that.
   integer function extras_binary_finish_step(binary_id)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer :: ierr
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if
      extras_binary_finish_step = keep_going

   end function extras_binary_finish_step

   subroutine extras_binary_after_evolve(binary_id, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if

   end subroutine extras_binary_after_evolve

   subroutine my_adjust_mdots(binary_id, ierr)
      use binary_def, only : binary_info, binary_ptr
      use const_def, only: dp
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr
      type (binary_info), pointer :: b
      real(dp) :: fixed_xfer_fraction
      ierr = 0
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
      write(*,*) 'failed in binary_ptr'
      return
      end if
      
      ! THIS IS WHERE YOU CAN IMPOSE THE MASS TRANSFER FRACTION
      ! In your minilab1, this looked like: 
      ! epsilon = 1 - alpha - beta - delta - gamma.
      ! In this minilab3, we want to only model beta (isotropic re-emission)
      ! and upsilon (L2 outflow), while all the rest is already set to zero
      ! in the defaults.
      b% fixed_xfer_fraction = 1 - b% mass_transfer_beta - b% s_donor% x_ctrl(1)    !!!modify this
      
      
      ! EDDINGTON ACCRETION RATE
      ! Usually, one should also eval mdot_edd here by calling the default
      ! functions using the ones provided through binary_lib. 
      ! But in our minilab3, we want to ignore Eddington limits anyway...
      b% mdot_edd = 0d0
      b% mdot_edd_eta = 0d0


      ! WIND MASS TRASNFER EFFICIENCY
      ! Usually, one should also eval the wind mass transfer efficiency 
      ! here by calling the default functions provided through binary_lib.
      ! But we want to ignore wind mass transfer for simplicity...
      b% mdot_wind_transfer(:) = 0d0
      b% wind_xfer_fraction(:) = 0d0


      ! MASS CHANGES IN THE TWO STARTS DUE TO MASS TRANSFER
      ! Set mdot for the donor
      b% s_donor% mstar_dot = b% mtransfer_rate     !!!modify this
      ! Set mdot for the accretor
      ! point_mass_i is 0 if both stars are evolved, is 1 if there is a BH!
      if (b% point_mass_i == 0) then
         b% component_mdot(b% a_i) = 0d0
      else
         b% component_mdot(b% a_i) = -b% mtransfer_rate* b% fixed_xfer_fraction   !!!modify this
      end if
      ! Accretion luminosity is useful only if you have a compact 
      ! accretor and want to use it to compute the Eddington limit, 
      ! but you can set it to zero if you want to ignore that...
      b% accretion_luminosity = 0d0


      ! mdot_system_transfer is mass lost from the vicinity of each star;
      ! such mass will be removing the angular momentum of the respective star.
      ! We want to model this for the accretor (you can access it via 
      ! b% mdot_system_transfer(b% a_i)), this is the 
      ! isotropic re-emission mode! But we want to ignore it for the donor.
      b% mdot_system_transfer(b% d_i) = 0d0
      b% mdot_system_transfer(b% a_i) = b% mtransfer_rate * b% mass_transfer_beta    !!!modify this

      ! mdot_system_cct is mass lost from a circumbinary coplanar toroid.
      ! we are not interestered in modeling this one :) 
      b% mdot_system_cct = 0d0 

   end subroutine my_adjust_mdots

   subroutine my_jdot_ml(binary_id, ierr)
      use binary_def, only : binary_info, binary_ptr
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr
      type (binary_info), pointer :: b
      real(dp) :: x_L2
      ierr = 0
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
      write(*,*) 'failed in binary_ptr'
      return
      end if

      ! THIS IS WHERE YOU CAN IMPOSE THE ANGULAR MOMENTUM LOSS RATE 
      ! ASSOCIATED WITH MASS LOSS
      ! Remember that you have two types of mass loss: 
      ! the isotropic re-emission mode (beta) and the L2 outflow (upsilon).
      ! The first one is already implemented in MESA, 
      ! we just need to find how to write it.
      ! Look at the default routine that MESA uses in 
      ! $MESA_DIR/binary/private/binary_jdot.f90, and copy the relevant piece.
      ! You can also check the formula that we wrote on the website for Jdot_isotropic, it should correspond :) 
      b% jdot_ml = 0d0
      b% jdot_ml = b% jdot_ml + (b% mdot_system_transfer(b% a_i) + b% mdot_system_wind(b% a_i))*&
      pow2(b% m(b% d_i)/(b% m(b% a_i)+b% m(b% d_i))*b% separation)*2*pi/b% period *&
      sqrt(1 - pow2(b% eccentricity))

      ! Now add the L2 outflow contribution, which is not included in the default MESA jdot routine, so you will have to write it from scratch using the formula on the website!
      ! Calculate the coordinate of L2 in units of separation
      x_L2 = abs(find_L2(b))
      ! Add the contribution to jdot from mass lost from L2
      b% jdot_ml = b% jdot_ml + (b% mtransfer_rate * b% s_donor% x_ctrl(1))*&
      ((b% m(b% a_i)/(b% m(b% a_i)+b% m(b% d_i))-x_L2)*b% separation)**2*2*pi/b% period 

   end subroutine my_jdot_ml

   ! ROCHE POTENTIAL FIRST DERIVATIVE
   ! To find the Lagrangian points numerically, by bisection
   real(dp) function dPhidx(b,x) result(derivative)
   real(dp), intent(in) :: x
   real(dp) :: q, x_cm
   type(binary_info), pointer :: b
   ! include 'formats.inc'

   q = b% m(b% d_i)/b% m(b% a_i)
   x_cm = 1/(1+q)
   derivative = 1/(x*abs(x)) +1/(q*(x-1)*abs(x-1)) -(x-x_cm)*(q+1)/q

   end function dPhidx


   ! FUNCTION TO FIND THE COORDINATE OF L2 IN UNITS OF SEPARATION
   real(dp) function find_L2(b) result(L2)
   real(dp) :: limit, tolerance, x, upper_bound, lower_bound, dPhi_new,q
   type(binary_info), pointer :: b
   ! include 'formats.inc'

   q = b% m(b% d_i)/b% m(b% a_i)

   if (q < 1) then
   upper_bound = 0d0
   lower_bound = -1d0
   limit = abs(upper_bound-lower_bound)/abs(lower_bound)
   end if

   if (q .GE. 1) then
   upper_bound = 2d0
   lower_bound = 1d0
   limit = abs(upper_bound-lower_bound)/abs(upper_bound)
   end if

   x = 0d0

   tolerance = 0.000001d0

   do while (limit > tolerance)
   x = (lower_bound+upper_bound)/2
   dPhi_new = dPhidx(b,x)
   if (dPhi_new > 0) then
         lower_bound = x
   else if (dPhi_new < 0) then
         upper_bound = x
   else
         exit
   end if

   if (q < 1) then
         limit = abs(upper_bound-lower_bound)/abs(lower_bound)
   end if

   if (q .GE. 1) then
         limit = abs(upper_bound-lower_bound)/abs(upper_bound)
   end if

   end do
   L2 = (upper_bound + lower_bound)/2
   end function find_L2

end module run_binary_extras
